package info.androidhive.androidvideostreaming;

public class AppConfig {
	public static final String STREAM_URL = "rtsp://192.168.43.233:1935/live/android_test";
	public static final String PUBLISHER_USERNAME = "ravi";
	public static final String PUBLISHER_PASSWORD = "passtemp";
}
