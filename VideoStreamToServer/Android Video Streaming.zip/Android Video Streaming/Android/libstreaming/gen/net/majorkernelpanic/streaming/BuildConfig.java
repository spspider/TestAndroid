/** Automatically generated file. DO NOT MODIFY */
package net.majorkernelpanic.streaming;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}