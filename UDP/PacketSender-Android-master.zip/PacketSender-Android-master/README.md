# Packet Sender for Android
This is the Android version of Packet Sender for Desktop. The project is not being actively developed, but it will accept pull requests.

<img alt="Packet Sender Android" width="250px" src="screenshots/android-screenshot-phone.png">

## Parent project
This was originally an attempt to rewrite the GPL-based desktop version:
https://github.com/dannagle/PacketSender


## License

MIT. Feel free to fork and make it your own.


## Copyright

Packet Sender is wholly owned and copyright &copy;  -  [@NagleCode](http://twitter.com/NagleCode) - [DanNagle.com](http://DanNagle.com)  -  [PacketSender.com](http://PacketSender.com)
