# AndroidUDPUtil
Simple Android UDP sender and receiver, accepts Broadcast

