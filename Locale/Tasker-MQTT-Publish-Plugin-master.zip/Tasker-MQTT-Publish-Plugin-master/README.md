# Tasker-MQTT-Publish-Plugin

Android Studio project based on [bodiroga/mqtter](https://github.com/bodiroga/mqtter) using locale module [LocaleAPI-AS](https://github.com/nosybore/LocaleAPI-AS) derived from [mkorcha's work] (https://github.com/mkorcha/LocaleAPI-AS).

Available for installation from the [Google Play Store](https://play.google.com/store/apps/details?id=net.nosybore.mqttpublishplugin) 
