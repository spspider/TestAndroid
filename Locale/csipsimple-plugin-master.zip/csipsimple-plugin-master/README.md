# CSipSimple Plugin

### What is it?
CSipSimple Plugin is a Locale/Tasker plugin to activate or deactivate sip accounts on the csipsimple apps.

#### Dependencies
CSipSimple Plugin depends on the locale plugin library available on the Locale developer website (http://www.twofortyfouram.com/developer.html). Simply download a sample project and you get the library.
