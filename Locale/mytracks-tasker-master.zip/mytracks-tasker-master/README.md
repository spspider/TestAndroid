Relevant developer sites:

* http://code.google.com/p/mytracks/wiki/MyTracksApi
* http://www.twofortyfouram.com/developer.html
* http://tasker.dinglisch.net/plugins.html
