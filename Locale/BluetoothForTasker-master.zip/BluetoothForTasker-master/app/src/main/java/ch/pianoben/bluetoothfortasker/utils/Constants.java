package ch.pianoben.bluetoothfortasker.utils;

public class Constants {
    public static final String SHARED_PREFERENCES_NAME = "ch.pianoben.bluetoothfortasker.preferences";
}
