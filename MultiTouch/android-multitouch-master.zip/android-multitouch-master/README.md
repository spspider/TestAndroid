android-multitouch
==================

Android multi touch example with scale, translate and rotate