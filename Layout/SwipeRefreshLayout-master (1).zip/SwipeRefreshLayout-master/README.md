# SwipeRefreshLayout
Simple example of using SwipeRefreshLayout
