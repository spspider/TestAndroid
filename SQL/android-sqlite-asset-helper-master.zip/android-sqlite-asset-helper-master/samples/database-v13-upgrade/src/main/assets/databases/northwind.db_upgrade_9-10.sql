-- nothing
INSERT INTO upgrades VALUES (10, "this;that");