-- nothing
CREATE TABLE upgrades (version INT, label TEXT);
INSERT INTO upgrades VALUES (9, "this;that");