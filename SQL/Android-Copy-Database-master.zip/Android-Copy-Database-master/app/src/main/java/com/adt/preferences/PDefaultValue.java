package com.adt.preferences;

/**
 * Shayan Rais (http://shanraisshan.com)
 * created on 1/4/2017
 */

public final class PDefaultValue {

    public static final int STAGE		    = -1;
    public static final int VERSION_CODE	= -1;
}
