/** Automatically generated file. DO NOT MODIFY */
package chintan.khetiya.sqlite.cursor;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}