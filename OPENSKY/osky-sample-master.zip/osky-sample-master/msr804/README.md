# Raw Data of Flight MH804

The flight left our reception range at 0:52 over Croatia and continued flying towards Cairo. It disappeared approximately 1.5h later (2:29) between Greece and Egypt.

Please note that by using these files you agree with the [Terms of Use](https://opensky-network.org/about/terms-of-use) of the OpenSky Network. In partciular, note that the data is provided on an "as is" basis! We do not make any warranties.

-- [OpenSky Network Association](http://opensky-network.org)
