---
name: Feature request
about: Suggest an idea for this project
title: "[Feature request] Title for the request"
labels: ''
assignees: ''

---

**What's your feature request? Please describe.**
A clear and concise description of what the request is. Ex. I would like to have X language support in text recognition[...]

**Mobile environment**
Android, IOS or both

**Additional context**
Add any other context or screenshots about the feature request here.
