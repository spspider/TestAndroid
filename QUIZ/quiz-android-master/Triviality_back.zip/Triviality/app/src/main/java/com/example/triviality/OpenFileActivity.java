package com.example.triviality;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

/**
 * Created by sp_1 on 27.03.2017.
 */

public class OpenFileActivity extends Activity {


    private static final int CHOOSE_FILE_REQUESTCODE = 101;
    public static final String LOG_TAG = "myLogs";

        final String FILENAME = "file";

        final String DIR_SD = "MyFiles";
        final String FILENAME_SD = "тест короткий.txt";

        /** Called when the activity is first created. */

        private static final int MENU_ITEM_ITEM1 = 1;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(Menu.NONE, MENU_ITEM_ITEM1, Menu.NONE, "StartTest");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case MENU_ITEM_ITEM1:
                Intent intent = new Intent(this,QuizActivity.class);
                startActivity(intent);
                return true;

            default:
                return false;
        }
    }
        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.openfile);
            //DbHelper db=new DbHelper(this);
           // quesList=db.getAllQuestions();
        }

        public void onclick(View v) {
            switch (v.getId()) {
                case R.id.btnWrite:
                    writeFile();
                    break;
                case R.id.btnRead:
                    readFile();
                    break;
                case R.id.btnWriteSD:
                    writeFileSD();
                    break;
                case R.id.btnReadSD:
                    readFileSD();
                    break;
                case R.id.OpenFileDialog:
                    openFile("*/*");
                    break;
            }
        }
    public void openFile(String minmeType) {

        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType(minmeType);
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        // special intent for Samsung file manager
        Intent sIntent = new Intent("com.sec.android.app.myfiles.PICK_DATA");
        // if you want any file type, you can skip next line
        sIntent.putExtra("CONTENT_TYPE", minmeType);
        sIntent.addCategory(Intent.CATEGORY_DEFAULT);

        Intent chooserIntent;
        if (getPackageManager().resolveActivity(sIntent, 0) != null){
            // it is device with samsung file manager
            chooserIntent = Intent.createChooser(sIntent, "Open file");
            chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[] { intent});
        }
        else {
            chooserIntent = Intent.createChooser(intent, "Open file");
        }

        try {
            startActivityForResult(chooserIntent, CHOOSE_FILE_REQUESTCODE);
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(getApplicationContext(), "No suitable File Manager was found.", Toast.LENGTH_SHORT).show();
        }
    }
        void writeFile() {
            try {
                // отрываем поток для записи
                BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
                        openFileOutput(FILENAME, MODE_PRIVATE)));
                // пишем данные
                bw.write("Содержимое файла");
                // закрываем поток
                bw.close();
                Log.d(LOG_TAG, "Файл записан");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        void readFile() {
            try {
                // открываем поток для чтения
                BufferedReader br = new BufferedReader(new InputStreamReader(
                        openFileInput(FILENAME)));
                String str = "";
                // читаем содержимое
                while ((str = br.readLine()) != null) {
                    Log.d(LOG_TAG, str);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        void writeFileSD() {
            // проверяем доступность SD
            if (!Environment.getExternalStorageState().equals(
                    Environment.MEDIA_MOUNTED)) {
                Log.d(LOG_TAG, "SD-карта не доступна: " + Environment.getExternalStorageState());
                return;
            }
            // получаем путь к SD
            File sdPath = Environment.getExternalStorageDirectory();
            // добавляем свой каталог к пути
            sdPath = new File(sdPath.getAbsolutePath() + "/" + DIR_SD);
            // создаем каталог
            sdPath.mkdirs();
            // формируем объект File, который содержит путь к файлу
            File sdFile = new File(sdPath, FILENAME_SD);
            try {
                // открываем поток для записи
                BufferedWriter bw = new BufferedWriter(new FileWriter(sdFile));
                // пишем данные
                bw.write("Содержимое файла на SD");
                // закрываем поток
                bw.close();
                Log.d(LOG_TAG, "Файл записан на SD: " + sdFile.getAbsolutePath());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        void readFileSD() {
            // проверяем доступность SD
            if (!Environment.getExternalStorageState().equals(
                    Environment.MEDIA_MOUNTED)) {
                Log.d(LOG_TAG, "SD-карта не доступна: " + Environment.getExternalStorageState());
                return;
            }
            // получаем путь к SD
            File sdPath = Environment.getExternalStorageDirectory();
            // добавляем свой каталог к пути
            sdPath = new File(sdPath.getAbsolutePath() + "/" + DIR_SD);
            // формируем объект File, который содержит путь к файлу
            File sdFile = new File(sdPath, FILENAME_SD);
            try {
                // открываем поток для чтения
                //InputStreamReader isr = new InputStreamReader(sdFile, "windows-1251");
                //BufferedReader br = new BufferedReader(isr);
                FileInputStream fstream1 = new FileInputStream(sdFile);
                DataInputStream in = new DataInputStream(fstream1);
                BufferedReader br = new BufferedReader(new InputStreamReader(in,"windows-1251"));
                //BufferedReader br = new BufferedReader(new FileReader(sdFile));
                String str = "";
                // читаем содержимое
                boolean next_title=false;
                boolean next_themes=false;
                boolean next_question=false;
                boolean next_answer=false;
                boolean next_right_answer=false;
                boolean next_negative_answer=false;
                String question ="",negative_answer="",right_answer="";
                String Question_is=new String();
                ArrayList<String> NAnswers=new ArrayList();
                String RAnswer=new String();
                int row=0;
                int question_row=0,Positive_row=0,Negative_row=0;
                boolean End_of_all_rows=false;

                while ((str = br.readLine()) != null) {
                    if (row!=0){
                        if (!str.equals("-")&&!str.equals("+")&&!str.contains("##time")&&!str.contains("##theme")&&!(str.length()<1)&&!(str.contains("\n"))) {

                            if (question_row == row) {
                                question += str;
                                //Log.d(LOG_TAG, "!Question_is:" + question);
                                question_row=row+1;
                            }
                            if (Positive_row == row) {
                                right_answer += str;
                                //Log.d(LOG_TAG, "!Positive_row:" + right_answer);
                                Positive_row=row+1;
                            }
                            if (Negative_row == row) {
                                negative_answer += str;
                                //Log.d(LOG_TAG, "!Negative_row:" + negative_answer);
                                Negative_row=row+1;
                            }
                        }
                        else{
                            Negative_row=Positive_row=question_row=0;
                                if (question!=""){
                                    Log.d(LOG_TAG, "!Question_is:" + question);
                                    Question_is=question;
                                    question="";
                                }
                            if (right_answer!=""){
                                Log.d(LOG_TAG, "!Positive_row:" + right_answer);
                                RAnswer=right_answer;
                                right_answer="";
                            }
                            if (negative_answer!=""){
                                Log.d(LOG_TAG, "!Negative_row:" + negative_answer);
                                NAnswers.add(negative_answer);
                                negative_answer="";
                            }
                            //Log.d(LOG_TAG, "!Question_is:" + question);
                            //Log.d(LOG_TAG, "!Positive_row:" + right_answer);
                            //Log.d(LOG_TAG, "!Negative_row:" + negative_answer);
                        }
                    }
                    if (next_title){Log.d(LOG_TAG, "!TITLE:"+str);next_title=false;}
                    if (next_themes){Log.d(LOG_TAG, "!THEMES:"+str);next_themes=false;}
                    if(str.equals("###TITLE###")){
                        next_title=true;
                    }
                    if(str.equals("###THEMES###")){
                        next_themes=true;
                    }

                    if(str.contains("##time")){
                        //если ##time найден, значит впереди - слудющий вопрос
                        question =negative_answer=right_answer="";
                        question_row = row+1;

                    }
                    if(str.equals("+")){
                        question =negative_answer=right_answer="";
                        Positive_row=row+1;

                    }
                    if(str.equals("-")){
                        question =negative_answer=right_answer="";
                        Negative_row=row+1;

                    }



                    if((str.equals("+")||(str.equals("-"))||(str.equals("\n"))||(str.equals("\t")||(str.isEmpty())||(str.contains("##"))))){
                        if (next_question) {                        //next_answer=true;
                            Question_is = question;
                            next_question=false;question="";
                            //Log.d(LOG_TAG, "!Question_is1:"+str);
                        }
                        if (next_right_answer){
                            RAnswer = right_answer;
                            next_right_answer=false;right_answer="";
                        }
                        if (next_negative_answer){
                            NAnswers.add(negative_answer);
                            next_negative_answer=false;negative_answer="";
                        }
                        //Log.d(LOG_TAG, "!question:"+question);
                    }


                    if((RAnswer!="")&&(NAnswers.size()>2)&&(Question_is!="")) {
                        DbHelper DB = new DbHelper(this);
                        //SQLiteDatabase db;
                        //db = DB.getWritableDatabase();
                        //db.insert()
                        Question q1 = new Question(1,Question_is, NAnswers.get(0), NAnswers.get(1), NAnswers.get(2), 1);
                        Log.d(LOG_TAG,Question_is);
                        //Question q1=new Question("What is JP?","Jalur Pesawat", "Jack sParrow", "Jasa Programmer", "Jasa Programmer");
                        //Log.d(LOG_TAG, q1.getANSWER()+q1.getOPT1()+q1.getQUESTION());

                        DB.addQuestion(q1);
                        //DB.close();
                        Question_is = RAnswer = "";
                        NAnswers.clear();
                    }
                    //Log.d(LOG_TAG, str);
                    row++;
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
}
