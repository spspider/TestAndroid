package com.example.triviality;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper {

	private static final String ANSWERS="answers_table";
	private static final String ID_THEME="id_theme";
	private static final String ID_QUESTION="id_question";
	private static final String ID_RIGHT_ANSWERS="id_right_answer";
	private static final String ID_YOUR_ANSWERS="id_your_answer";

	private static final int DATABASE_VERSION = 1;
	// Database Name
	private static final String DATABASE_NAME = "triviaQuiz";
	// tasks table name
	private static final String TABLE_QUEST = "quest";
	private static final String TABLE_THEME = "THEME_TABLE";
	private static final String KEY_NAME_THEME = "theme_name";
	// tasks Table Columns names
	private static final String KEY_ID = "id";
	private static final String KEY_THEME="theme";
	private static final String KEY_QUES = "question";
	private static final String KEY_ANSWER = "answer"; //correct option
	private static final String KEY_OPT1= "opt1"; //option a
	private static final String KEY_OPT2= "opt2"; //option b
	private static final String KEY_OPT3= "opt3"; //option c
	private static final String KEY_OPT4= "opt4"; //option c
	private SQLiteDatabase dbase;
	public DbHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}
	@Override
	public void onCreate(SQLiteDatabase db) {
		dbase=db;
		String sql = "CREATE TABLE IF NOT EXISTS " + TABLE_QUEST + " ( "
				+ KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
				+KEY_THEME + " INTEGER, "
				+ KEY_QUES+ " TEXT, "
				+ KEY_ANSWER+ " INTEGER, "
				+KEY_OPT1 +" TEXT, "
				+KEY_OPT2 +" TEXT, "
				+KEY_OPT3+" TEXT, "
				+KEY_OPT4+" TEXT" +
				")";
		db.execSQL(sql);
		Log.d(OpenFileActivity.LOG_TAG,sql);
		//addQuestions();
		//db.close();

		String sql2 = "CREATE TABLE IF NOT EXISTS " + TABLE_THEME + " ( "
				+ KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
				+ KEY_NAME_THEME+ " TEXT" +
				")";
		db.execSQL(sql2);
		Log.d(OpenFileActivity.LOG_TAG,sql2);
		String sql3 = "CREATE TABLE IF NOT EXISTS " + ANSWERS + " ( "
				+ KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
				+ ID_THEME+ " INTEGER,"
				+ ID_QUESTION+ " INTEGER,"
				+ ID_YOUR_ANSWERS+ " INTEGER,"
				+ ID_RIGHT_ANSWERS+ " INTEGER"
				+")";
		db.execSQL(sql3);


		Log.d(OpenFileActivity.LOG_TAG,sql3);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
		// Drop older table if existed
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUEST);
		// Create tables again
		onCreate(db);
	}
	// Adding new question
	public void addQuestion(Question quest) {
		//dbase.
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(KEY_THEME, quest.getTHEMEID());
		values.put(KEY_QUES, quest.getQUESTION()); 
		values.put(KEY_OPT1, quest.getOPT1());
		values.put(KEY_OPT2, quest.getOPT2());
		values.put(KEY_OPT3, quest.getOPT3());
		values.put(KEY_OPT4, quest.getOPT4());
		values.put(KEY_ANSWER, quest.getANSWER());
		// Inserting Row
		Log.d(OpenFileActivity.LOG_TAG, String.valueOf(values));
		db.insert(TABLE_QUEST, null, values);
	}
	public List<Question> getAllQuestions() {
		List<Question> quesList = new ArrayList<Question>();
		// Select All Query
		String selectQuery = "SELECT  * FROM " + TABLE_QUEST;
		dbase=this.getReadableDatabase();
		Cursor cursor = dbase.rawQuery(selectQuery, null);
		// looping through all rows and adding to list
		if (cursor.moveToFirst()) {
			do {
				Question quest = new Question();
				quest.setID(cursor.getInt(0));
				//quest.se(cursor.getString(1));
				quest.setTHEMEID(cursor.getInt(1));
				quest.setQUESTION(cursor.getString(2));
				quest.setANSWER(cursor.getInt(3));
				quest.setOPT1(cursor.getString(4));
				quest.setOPT2(cursor.getString(5));
				quest.setOPT3(cursor.getString(6));
				quest.setOPT4(cursor.getString(7));
				quesList.add(quest);
			} while (cursor.moveToNext());
		}
		// return quest list
		return quesList;
	}
	public int rowcount()
	{
		int row=0;
		String selectQuery = "SELECT  * FROM " + TABLE_QUEST;
		SQLiteDatabase db = this.getWritableDatabase();
		Cursor cursor = db.rawQuery(selectQuery, null);
		row=cursor.getCount();
		return row;
	}
}
