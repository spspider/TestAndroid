package com.example.ttester_paukov.drawer;

/**
 * Created by tanja on 04.05.2017.
 */

public interface OnBackPressedListener {
    void doBack();
}
