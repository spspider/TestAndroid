package com.example.ttester_paukov.Utils;

import java.util.ArrayList;

public class Singleton_ALLANSWERS {
    ArrayList<String> ALLANSWERS;
    String TEX_ANSWERS;
    String KEY_THEME;
    String KEY_ID_OF_QUEST;
    String KEY_ID_OF_NANSWERS;

    public String getTEX_ANSWERS() {
        return TEX_ANSWERS;
    }

    public void setTEX_ANSWERS(String TEX_ANSWERS) {
        this.TEX_ANSWERS=TEX_ANSWERS;
    }

    public void setKEY_THEME(String KEY_THEME) {
    }

    public void setKEY_ID_OF_QUEST(String KEY_ID_OF_QUEST) {
    }

    public void setKEY_ID_OF_NANSWERS(String KEY_ID_OF_NANSWERS) {
    }
}
