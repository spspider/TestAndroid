package com.example.ttester_paukov.drawer;

public interface NavigationDrawerCallbacks {
    void onNavigationDrawerItemSelected(int position);
}
