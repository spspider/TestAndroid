package com.example.ttester_paukov.dynamicviewpager;

import android.content.Context;
import androidx.viewpager.widget.ViewPager;
import android.util.AttributeSet;

/**
 * Created by anskaal on 2/29/16.
 */
public class DynamicViewPager extends ViewPager {

    public DynamicViewPager(Context context) {
        super(context);
    }

    public DynamicViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

}
