package com.example.ttester_paukov.Utils;

public class Alist {
     private String name;
     private String gender;

    public Alist(String name, String gender) {
        this.name = name;
        this.gender = gender;
    }

    public String getQuestion() {
        return name;
    }
}