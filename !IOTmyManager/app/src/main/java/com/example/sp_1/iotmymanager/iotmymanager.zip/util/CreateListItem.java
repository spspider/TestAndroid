package com.example.sp_1.iotmymanager.util;

import android.app.Activity;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.sp_1.iotmymanager.FragmentActivityA;
import com.example.sp_1.iotmymanager.MainActivity;
import com.example.sp_1.iotmymanager.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.R.attr.tabWidgetStyle;
import static android.R.attr.tag;
import static com.example.sp_1.iotmymanager.FragmentActivityA.myLog;
import static com.example.sp_1.iotmymanager.R.id.myLiLa;


/**
 * Created by sp_1 on 12.01.2017.
 */

public class CreateListItem {
    private GlobalClass app;
    private Activity activity;
    private MainActivity getMainactivity2;
    private FragmentActivityA fragmentActivityA;
    private Fragment myFragment;

    LayoutInflater ltInflater;
    LinearLayout linLayout;
    //private MainActivity getMainactivity;

    //////////////////////////////////////////////////
    private static String makeFragmentName(int viewId, int position) {
        return "android:switcher:" + viewId + ":" + position;
    }
public Fragment getFragment(int page){
    GlobalClass GC = GlobalClass.getInstance();
    fragmentActivityA = (FragmentActivityA) GC.getFragment();
    ViewPager mViewPager = GC.getPager();

        String name = makeFragmentName(mViewPager.getId(), page);
        Fragment viewPagerFragment = fragmentActivityA.getFragmentManager().findFragmentByTag(name);
        // OR Fragment viewPagerFragment = getFragmentManager().findFragmentByTag(name);
        if(viewPagerFragment != null) {
            return viewPagerFragment;
        }
    return null;

}
///////////////////////////////////////////////
    public void createInflater(){

        //linLayout = (LinearLayout) getMainactivity2.findViewById()
        //fragmentActivityA = (FragmentActivityA) GlobalClass.getInstance().getFragment();
        //myFragment = fragmentActivityA.getFragmentManager().findFragmentByTag("android:switcher:2131492971:0");
        fragmentActivityA = (FragmentActivityA) getFragment(0);
        myFragment = fragmentActivityA;
        //myFragment = getFragment(0);
//myFragment.getRegisteredFragment(0);

        linLayout = (LinearLayout) myFragment.getView().findViewById(myLiLa);
        ltInflater =  myFragment.getActivity().getLayoutInflater();

    }
    public void printAllHashMap(ArrayList<HashMap<String, String>> contactList){
        //getMainactivity2 = (MainActivity) GlobalClass.getInstance().getActivity();
        fragmentActivityA = (FragmentActivityA) GlobalClass.getInstance().getFragment();
        myLog("-printing----------------------------------", 0);

        if (ltInflater==null){createInflater();}
        ////////////////////////////////////////////////////////////
        View item = ltInflater.inflate(R.layout.item, linLayout, false);

        for(Map<String, String> map : contactList) {
                String widget = map.get("widget");
                switch (widget) {
                    case "toggle":
                        Button btnNew = new Button(myFragment.getActivity());
                        btnNew.setText(map.get("descr"));
                        btnNew.setOnClickListener(new ClickListener(btnNew.getId(),map.get("id")));

                        linLayout.addView(btnNew, item.getLayoutParams());
                        break;
                    case "range":

                        break;
                }


            TextView tvName = (TextView) item.findViewById(R.id.tvName);
            tvName.setText(map.get("descr"));
            TextView tvPosition = (TextView) item.findViewById(R.id.tvPosition);
            tvPosition.setText("page: " + (map.get("page")));
            TextView tvSalary = (TextView) item.findViewById(R.id.tvSalary);
            tvSalary.setText("widget: " + (map.get("widget")));
            item.getLayoutParams().width = LinearLayout.LayoutParams.MATCH_PARENT;
            //item.setBackgroundColor(colors[i % 2]);
            linLayout.addView(item);
        }
        ////////////////////////////////////////////////////////////
        for(Map<String, String> map : contactList)
        {
            String tagName = map.get("id");
            //myFragment = getFragment(0);
            FragmentActivityA fragmentActivity = (FragmentActivityA) getFragment(2);
            fragmentActivity.myLog(tagName, 0);

            //System.out.println(tagName);

        }
    }





}
