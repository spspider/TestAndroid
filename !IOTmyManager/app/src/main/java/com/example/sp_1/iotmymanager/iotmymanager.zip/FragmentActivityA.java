package com.example.sp_1.iotmymanager;


import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.sp_1.iotmymanager.util.GlobalClass;


/**
 * Created by sp_1 on 25.01.2017.
 */

public class FragmentActivityA extends BaseFragment {
    private static TextView tv,tv2;
    private GlobalClass app;

    public Activity RunningActivity;
    static final String ARGUMENT_PAGE_NUMBER = "arg_page_number";

    public int pageNumber;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.layout_fragment, container, false);
        //getFragmentManager().findFragmentById(R.id.viewpager).getView().findViewById(R.id.viewpager);
        //RunningActivity = FragmentActivityA.getActivity();
        //getFragmentManager().findFragmentByTag("");
        LinearLayout ll = (LinearLayout) v.findViewById(R.id.lMain);
        tv = new TextView(getActivity());
        tv.setText("");
        ll.addView(tv);
        scrollView1 = (ScrollView) v.findViewById(R.id.scrollView2);
        myLog("test", pageNumber);

        app = (GlobalClass) getActivity().getApplication().getApplicationContext();
        app.setFragment(this);
        myLog("page: "+pageNumber,pageNumber);


        return v;
       }

    public static void myLog(String str, int page) {
         tv.append(str + "\n");
            scrollView1.post(new Runnable() {
                @Override
                public void run() {
                    scrollView1.fullScroll(View.FOCUS_DOWN);
                }
            });
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pageNumber = getArguments().getInt(ARGUMENT_PAGE_NUMBER);

    }


    public static FragmentActivityA newInstance(int pos) {

        FragmentActivityA f = new FragmentActivityA();
        Bundle arguments = new Bundle();
        arguments.putInt(ARGUMENT_PAGE_NUMBER, pos);
        //arguments.putString("","");
        //arguments.putString("");
        f.setArguments(arguments);
        return f;
    }




}
