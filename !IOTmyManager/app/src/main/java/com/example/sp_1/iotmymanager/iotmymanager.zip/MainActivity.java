package com.example.sp_1.iotmymanager;

import android.app.FragmentTransaction;
import android.app.SearchManager;
import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.widget.SearchView;
import android.text.style.TtsSpan;
import android.util.Log;
import android.view.MenuInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.TabHost;
import android.widget.TextView;

import com.example.sp_1.iotmymanager.util.GlobalClass;
import com.example.sp_1.iotmymanager.util.JsonParcer_MQTT_subscribe;

import java.nio.DoubleBuffer;

import static com.example.sp_1.iotmymanager.R.id.scrollView1;
import static com.example.sp_1.iotmymanager.R.layout.item;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private GlobalClass app;
    public  ViewPager pager;
public static String firstTag;
    String TAG = "log_m";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        app = (GlobalClass) getApplication().getApplicationContext();
        app.setActivity(this);
        app.setContext(this);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer,toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        /////////////////////pager////////////////////////////////////////
        pager = (ViewPager) findViewById(R.id.pager);
        pager.setAdapter(new MyPagerAdapter(getSupportFragmentManager()));

        if(savedInstanceState != null) {
            int tabIndex = savedInstanceState.getInt("tabIndex");
            pager.setCurrentItem(tabIndex, false);
        }
        pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                Log.d(TAG, "onPageSelected, position = " + position);
                //FragmentActivityA.myLog("pageListener: "+position);
                GlobalClass.getInstance().setSelectedPage(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

        });
        GlobalClass GC = GlobalClass.getInstance();
        GC.setPager(pager);
    };


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }



    private class MyPagerAdapter extends FragmentPagerAdapter {
        private Fragment mCurrentFragment;
        public Fragment getCurrentFragment() {
            return mCurrentFragment;
        }
        @Override
        public void setPrimaryItem(ViewGroup container, int position, Object object) {
            if (getCurrentFragment() != object) {
                mCurrentFragment = ((Fragment) object);
            }
            super.setPrimaryItem(container, position, object);
        }

        public MyPagerAdapter(FragmentManager fm) {
            super(fm);
        }
        @Override
        public Fragment getItem(int pos) {

            //DoubleBuffer mPageReferenceMap;
           // mPageReferenceMap.put(index, myFragment);
            return FragmentActivityA.newInstance(pos);


        }
/*
        @Override
        public Fragment getItem(int pos) {
            switch (pos) {

                case 0:
                    return FragmentActivityA.newInstance();
                case 1:
                    //return TutorialFragmentB.newInstance();
                case 2:
                    //return TutorialFragmentC.newInstance(getResources().getString(R.string.tutorial_pageC1_title), getResources().getString(R.string.tutorial_pageC1_text));
                case 3:
                    //return TutorialFragmentC.newInstance(getResources().getString(R.string.tutorial_pageC2_title), getResources().getString(R.string.tutorial_pageC2_text));
                default:
                    return FragmentActivityB.newInstance();
                    //return null;
            }
        }
*/
        @Override
        public int getCount() {
            return 4;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "Welcome";
                case 1:
                    return "Kitchen";
                case 2:
                    return "Phone";
                case 3:
                    return "Registered Device";
            }

            return null;
        }
        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            Fragment createdFragment = (Fragment) super.instantiateItem(container, position);
            //getSupportFragmentManager().beginTransaction().add(createdFragment, "first").commit();
            Log.d(TAG, "TAG:" + createdFragment.getTag());
            return createdFragment;

        }

    }

    /*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getActivity().getMenuInflater().inflate(R.menu.menu, menu);
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    */
/*
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
*/
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            JsonParcer_MQTT_subscribe parcer = new JsonParcer_MQTT_subscribe();
            //String Allvalues = parcer.insertMessage("","");
            String message = "{\"id\":\"2\",\"page\":\"Kitchen\",\"descr\":\"Dimmer\",\"widget\":\"range\",\"topic\":\"/IoTmanager/dev01-kitchen/dim-light\",\"style\":\"range-calm\",\"badge\":\"badge-assertive\",\"leftIcon\":\"ion-ios-rainy-outline\",\"rightIcon\":\"ion-ios-rainy\"}";
            String message2 = "{\"id\":\"1\",\"page\":\"Kitchen\",\"descr\":\"Light-1\",\"widget\":\"toggle\",\"topic\":\"/IoTmanager/dev01-kitchen/light1\",\"color\":\"orange\"}";
            String message3 ="{\"id\":\"0\",\"page\":\"Kitchen\",\"descr\":\"Light-0\",\"widget\":\"toggle\",\"topic\":\"/IoTmanager/dev01-kitchen/light0\",\"color\":\"blue\"}";
            String message4 =  "{\"id\":\"3\",\"page\":\"Kitchen\",\"descr\":\"ADC\",\"widget\":\"small-badge\",\"topic\":\"/IoTmanager/dev01-kitchen/ADC\",\"badge\":\"badge-balanced\"}";
            String message5 = "{\"id\":\"4\",\"page\":\"Outdoor\",\"descr\":\"Garden light\",\"widget\":\"toggle\",\"topic\":\"/IoTmanager/dev01-kitchen/light4\",\"color\":\"red\"}";
            //message = getResources().getString(R.string.json_str);
            //String message3  = Resources.getSystem().getString(R.string.json_str);
            //myLog(message3);
            parcer.insertMessage(message,"");
            parcer.insertMessage(message2,"");
            parcer.insertMessage(message3,"");
            parcer.insertMessage(message4,"");
            parcer.insertMessage(message5,"");
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
