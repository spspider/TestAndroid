package com.example.sp_1.iotmymanager.util;

import android.app.Activity;
import android.view.View;
import android.widget.Button;

import com.example.sp_1.iotmymanager.FragmentActivityA;
import com.example.sp_1.iotmymanager.MainActivity;

/**
 * Created by sp_1 on 16.01.2017.
 */

public class ClickListener extends Activity implements View.OnClickListener {
    private MainActivity getMainactivity2;
    private FragmentActivityA fragmentActivityA;
    //private Activity activity;
    private int idBtn;
    private String idDevice;

    public ClickListener(int id, String idDevice) {
        this.idBtn = id;
        this.idDevice = idDevice;
    }

    @Override
    public void onClick(View v) {

        Button btn = (Button)v;
        fragmentActivityA = (FragmentActivityA) GlobalClass.getInstance().getFragment();
        fragmentActivityA.myLog("нажата кнопка: "+v.getId()+btn.getText(), 0);
        //btn.getId()
        //idDevice.
        switch (v.getId()) {
            case 1:
                break;

        }

    }
}