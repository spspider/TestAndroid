package com.example.sp_1.iotmymanager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.widget.ScrollView;

import static android.content.ContentValues.TAG;
import static com.example.sp_1.iotmymanager.FragmentActivityA.myLog;

/**
 * Created by sp_1 on 25.01.2017.
 */

public class BaseFragment extends Fragment {
    BroadcastReceiver br;

    public static ScrollView scrollView1;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


/////////broadcast reciever////////////////////////////
        br = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                String task = intent.getStringExtra("backString");

                   myLog(task, 0);


                Log.d("my_log","recieved");
            }

        };

        IntentFilter intFilt = new IntentFilter("RECIVEFILTER");
        // регистрируем (включаем) BroadcastReceiver
        getActivity().registerReceiver(br, intFilt);
///////////////////////////////
        setHasOptionsMenu(true);


    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        Log.d(TAG, ".onCreateOptions() entered");
        getActivity().getMenuInflater().inflate(R.menu.main, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }
}
