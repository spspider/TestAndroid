package com.example.sp_1.iotmymanager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import static android.content.ContentValues.TAG;

/**
 * Created by sp_1 on 25.01.2017.
 */

public class FragmentActivityB extends BaseFragment {
    private final static String TAG = FragmentActivityB.class.getName();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.layout_fragment, container, false);
        return v;
    }

    public static FragmentActivityB newInstance() {

        FragmentActivityB f = new FragmentActivityB();

        return f;
    }

    private void handleSkip() {
        Log.d(TAG, ".handleSkip() entered");
        Intent loginIntent = new Intent(getActivity().getApplicationContext(), MainActivity.class);
        startActivity(loginIntent);
    }
}
