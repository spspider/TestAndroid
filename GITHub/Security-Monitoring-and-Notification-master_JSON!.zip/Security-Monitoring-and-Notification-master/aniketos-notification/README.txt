Notification module bundles
-impl (MAVEN): Notification module implementation bundle. Provides the notification module as a local OSGi service
-interface (MAVEN): Provides the notification interface and public type classes
-client (MAVEN): A reference client that consumes notifications from a remote broker
-feature (MAVEN): Karaf feature