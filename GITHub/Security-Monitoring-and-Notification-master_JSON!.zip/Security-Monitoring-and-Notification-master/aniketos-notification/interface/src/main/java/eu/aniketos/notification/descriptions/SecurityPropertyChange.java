package eu.aniketos.notification.descriptions;

public class SecurityPropertyChange {
	

	/** Separation of duty; ??? expected in value **/
	public static final String SEPARATION_OF_DUTY = "Separation of duty";
	
	/** Binding of duty; ??? expected in value **/
	public static final String BINDING_OF_DUTY = "Binding of duty";
	
}
