package eu.aniketos.notification.descriptions;

public class ContractViolation {
	

	/** The service  **/
	public static final String SERVICE_DOWNTIME = "Service downtime";
	
}
