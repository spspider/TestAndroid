Aniketos Notification module
==============

Short description
-----------------
The Aniketos Notification module is composed of X components: ... and the android client (located on te android Client folder). Please refer to the the android client readme for more details about the client itself. 

Overview 
--------
(Component’s function and place in Aniketos. 15 lines max; if more is needed, split up in sections of the same max. size)

Requirements
------------
(15 lines max; if more is needed, split up in sections of the same max. size)

Features
--------
(15 lines max; if more is needed, split up in sections of the same max. size)

How to get started
------------------
(15 lines max; if more is needed, split up in sections of the same max. size)

Contributing (guide)
--------------------
(15 lines max; if more is needed, split up in sections of the same max. size)

Installation
------------
Notification module bundles are Maven-built, and can be installed in Apache Karaf as features:
- aniketos-notification-service: Notification module implementation bundle. Provides the notification platform service as a local OSGi service.
- aniketos-notification-interface: Provides the notification interface and public type classes.
- aniketos-notification-client: A reference client that consumes notifications from a remote broker.
- aniketos-notification-trigger: A notification trigger that can replace any environment monitor for testing/demonstration purposes.

Modules, APIs
-------------
(15 lines max; if more is needed, split up in sections of the same max. size)

Usage manual
------------
(15 lines max; if more is needed, split up in sections of the same max. size)

Example usage
-------------
(15 lines max; if more is needed, split up in sections of the same max. size)

Credits
-------
(15 lines max; if more is needed, split up in sections of the same max. size)

Official site, external resources
---------------------------------
(15 lines max; if more is needed, split up in sections of the same max. size)

About the developers of this component
--------------------------------------
(15 lines max; if more is needed, split up in sections of the same max. size)

Updates and list of known issues
--------------------------------
(15 lines max; if more is needed, split up in sections of the same max. size)

