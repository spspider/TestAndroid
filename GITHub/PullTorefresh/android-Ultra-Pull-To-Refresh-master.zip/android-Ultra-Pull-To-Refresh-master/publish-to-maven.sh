python update-project.py
./gradlew clean :ptr-lib:uploadArchives
