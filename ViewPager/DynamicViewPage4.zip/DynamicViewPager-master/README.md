# DynamicViewPager

Viewpager Demo

* Viewpager for add or remove pages dynamically
