package com.example.hp.myapplication;

import android.content.Context;
import android.widget.ImageView;

/**
 * Created by HP on 10/08/2016.
 */
public class ClassImageView extends ImageView {

    public ClassImageView(Context context) {
        super(context);
    }
}
