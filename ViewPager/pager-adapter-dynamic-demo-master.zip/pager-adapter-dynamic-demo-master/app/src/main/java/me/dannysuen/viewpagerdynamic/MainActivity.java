package me.dannysuen.viewpagerdynamic;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.pager)
    ViewPager mPager;

    FragmentStatePagerAdapter mAdapter;

    Fragment mFragmentA;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        mFragmentA = new SimpleFragment();

        mAdapter = new FragmentStatePagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return mFragmentA;
            }

            @Override
            public int getCount() {
                return 1;
            }

            @Override
            public int getItemPosition(Object object) {
                return POSITION_NONE;
            }
        };

        mPager.setAdapter(mAdapter);
    }

    @OnClick(R.id.add_page_btn)
    public void addNewPage(View view) {
        mAdapter = new FragmentStatePagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                if (position == 0) {
                    return mFragmentA;
                }
                return new SimpleFragment();
            }

            @Override
            public int getCount() {
                return 2;
            }
        };


        mPager.setAdapter(mAdapter);


    }
}
