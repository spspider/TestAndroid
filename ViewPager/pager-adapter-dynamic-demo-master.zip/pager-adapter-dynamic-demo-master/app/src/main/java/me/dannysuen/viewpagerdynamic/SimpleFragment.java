package me.dannysuen.viewpagerdynamic;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import hugo.weaving.DebugLog;


/**
 * A simple {@link Fragment} subclass.
 */
public class SimpleFragment extends Fragment {


    public SimpleFragment() {
        // Required empty public constructor
    }

    @DebugLog
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_simple, container, false);
    }

    @DebugLog
    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}
