package com.example.anskaal.dynamicviewpager;

import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private DynamicViewPager mViewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mViewPager = (DynamicViewPager) findViewById(R.id.viewPager);
        DynamicViewPagerAdapter adapter = new DynamicViewPagerAdapter(getSupportFragmentManager());
        mViewPager.setAdapter(adapter);

        ArrayList<Fragment> fragments = new ArrayList<>();
        fragments.add(MyFragment.newInstance(1));
        fragments.add(MyFragment.newInstance(2));
        fragments.add(MyFragment.newInstance(3));
        adapter.setItems(fragments);

        mViewPager.setCurrentItem(1);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mViewPager = null;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_fullscreen, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_download) {

            ArrayList<Fragment> fragments = new ArrayList<>();
            fragments.add(MyFragment.newInstance(0));
            fragments.add(MyFragment.newInstance(1));
            fragments.add(MyFragment.newInstance(2));
            fragments.add(MyFragment.newInstance(3));
            fragments.add(MyFragment.newInstance(4));

            DynamicViewPagerAdapter adapter = new DynamicViewPagerAdapter(getSupportFragmentManager());
            adapter.setItems(fragments);

            mViewPager.setAdapter(adapter);
            mViewPager.setCurrentItem(2);

            return true;
        }

        return false;
    }
}
