# DynamicViewPagerSolution

The ViewPager and FragmentStatePagerAdapter in Android does not handle 
dynamic conditions very well. In this project I demonstrate how to work around 
this issue by creating and setting a new PagerAdapter to the View pager every time 
the content change...
