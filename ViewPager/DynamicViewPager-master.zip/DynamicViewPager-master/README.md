DynamicViewPager
================

An extension of androids ViewPager class with a PagerAdapter. You can add/replace/delete pages.
Use the DynamicTabViewPagerAdapter without additional implementation.
Additional exist the LockableViewPager to lock or unlock swiping.

Required
========

The DynamicTabViewPagerAdapter depence on the ActionBar-Compat library.
