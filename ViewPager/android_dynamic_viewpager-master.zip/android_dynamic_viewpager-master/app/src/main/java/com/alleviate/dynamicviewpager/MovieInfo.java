package com.alleviate.dynamicviewpager;

/**
 * Created by felix on 2/6/16.
 * Created at Alleviate.
 * shirishkadam.com
 */
public class MovieInfo {

    String mname, mphase;
    int mid;

    public MovieInfo(int mid, String mname, String mphase) {

        this.mid = mid;
        this.mname = mname;
        this.mphase = mphase;
    }
}
