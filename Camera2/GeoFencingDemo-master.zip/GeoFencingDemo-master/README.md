### GeoFencingDemo

This is a proof of concept implementation of geofencing on android platform. This app can track the specific geo-location of a user, take pictures of themselves and premises using front and rear camera. Captured information can be stored or shared accordingly via email or other means.


### Credits

### Maintainers

[Prembabu Panchadara](http://github.com/preym), The Egghead Creative

[Surbhi Katyayani](http://github.com/surbhikatyayani), The Egghead Creative

### License

Copyright (c) 2013-2016 The Egghead Creative. This software is licensed under the MIT License.
