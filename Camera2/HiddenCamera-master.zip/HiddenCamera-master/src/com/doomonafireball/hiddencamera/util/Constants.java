package com.doomonafireball.hiddencamera.util;

/**
 * Created with IntelliJ IDEA.
 * User: Derek
 * Date: 4/4/12
 * Time: 8:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class Constants {
    public static final String DEBUG_TAG = "HiddenCamera";
}
