/** Automatically generated file. DO NOT MODIFY */
package pl.quaternion.sms2picturebyemail;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}