By using this application you accept that images taken by this application will be made *publically* available at http://imgur.com and emails (including email address) will be processed by http://jangomail.com.


