DoubleCamera
============

A spy camera, saving one copy to normal path while another to a hidden path.
