# MQTT Patterns
Android App MQTT client for IoT 

This MQTT Client provides a simple implementation capable of one connection at the time, publishing and multiple subscriptions to any given topic.

It supports only a single CA file for SSL/TLS as of this version, however, work is in progress to add a client private key and certificate.

The code is open source and is based on the Paho library by Eclipse.

This is a Beta version. Any bug, comments and suggestions reported are greatly appreciated to improve this application for further and better use. 

-The team at IO-Patterns-
