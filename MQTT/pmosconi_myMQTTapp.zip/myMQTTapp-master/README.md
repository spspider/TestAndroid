# myMQTTapp
MQTT-based Android application for IOT
 
