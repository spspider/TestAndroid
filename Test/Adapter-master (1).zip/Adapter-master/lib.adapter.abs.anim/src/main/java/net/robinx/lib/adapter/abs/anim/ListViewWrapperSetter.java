package net.robinx.lib.adapter.abs.anim;

import android.support.annotation.NonNull;

public interface ListViewWrapperSetter {

    void setListViewWrapper(@NonNull final ListViewWrapper listViewWrapper);
}
