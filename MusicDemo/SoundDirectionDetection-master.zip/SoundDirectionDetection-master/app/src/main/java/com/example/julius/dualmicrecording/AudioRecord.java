package com.example.julius.dualmicrecording;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import android.media.MediaPlayer;
import android.media.MediaRecorder;

import android.os.Environment;

import android.view.View;
import android.widget.Button;

import android.widget.Toast;
import java.io.IOException;

public class AudioRecord {

}
