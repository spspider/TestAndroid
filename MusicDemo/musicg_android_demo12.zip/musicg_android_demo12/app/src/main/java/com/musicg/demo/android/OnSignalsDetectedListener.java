package com.musicg.demo.android;

public interface OnSignalsDetectedListener{
	public abstract void onWhistleDetected();
}